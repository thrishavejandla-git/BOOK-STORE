import React, { createContext, useContext, useState, useMemo } from 'react';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [items, setItems] = useState([]); // [{ book, quantity }]

  const addToCart = (book) => {
    setItems((prev) => {
      const existing = prev.find((it) => it.book._id === book._id);
      if (existing) {
        return prev.map((it) =>
          it.book._id === book._id ? { ...it, quantity: it.quantity + 1 } : it
        );
      }
      return [...prev, { book, quantity: 1 }];
    });
  };

  const removeFromCart = (bookId) => {
    setItems((prev) => prev.filter((it) => it.book._id !== bookId));
  };

  const updateQuantity = (bookId, quantity) => {
    setItems((prev) =>
      prev.map((it) => (it.book._id === bookId ? { ...it, quantity: Math.max(1, quantity) } : it))
    );
  };

  const clearCart = () => setItems([]);

  const totalItems = useMemo(() => items.reduce((sum, it) => sum + it.quantity, 0), [items]);
  const totalPrice = useMemo(
    () => items.reduce((sum, it) => sum + it.quantity * it.book.price, 0),
    [items]
  );

  return (
    <CartContext.Provider
      value={{ items, addToCart, removeFromCart, updateQuantity, clearCart, totalItems, totalPrice }}
    >
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within a CartProvider');
  return ctx;
}
