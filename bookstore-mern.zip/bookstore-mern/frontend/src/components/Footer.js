import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <p>Nightjar &amp; Co. — open past midnight, on the shelf and off it.</p>
        <p className="footer-meta">Built with the MERN stack.</p>
      </div>
    </footer>
  );
}

export default Footer;
