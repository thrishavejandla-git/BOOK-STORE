import React from 'react';

function Loader({ label = 'Loading…' }) {
  return (
    <div className="loader">
      <div className="loader-mark" aria-hidden="true" />
      <p>{label}</p>
    </div>
  );
}

export default Loader;
