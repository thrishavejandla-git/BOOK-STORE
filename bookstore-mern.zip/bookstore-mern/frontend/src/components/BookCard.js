import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

function BookCard({ book }) {
  const { addToCart } = useCart();

  return (
    <article className="book-card">
      <Link to={`/books/${book._id}`} className="book-card-cover">
        {book.image ? (
          <img src={book.image} alt={book.title} loading="lazy" />
        ) : (
          <div className="book-card-cover placeholder">{book.title.charAt(0)}</div>
        )}
      </Link>
      <div className="book-card-body">
        <p className="book-card-genre">{book.genre}</p>
        <h3 className="book-card-title">
          <Link to={`/books/${book._id}`}>{book.title}</Link>
        </h3>
        <p className="book-card-author">by {book.author}</p>
        <div className="book-card-footer">
          <span className="book-card-price">₹{book.price}</span>
          <button className="btn btn-small" onClick={() => addToCart(book)}>
            Add to cart
          </button>
        </div>
      </div>
    </article>
  );
}

export default BookCard;
