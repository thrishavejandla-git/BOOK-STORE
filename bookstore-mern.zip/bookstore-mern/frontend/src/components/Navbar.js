import React from 'react';
import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

function Navbar() {
  const { totalItems } = useCart();
  const { user, logout } = useAuth();

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          <span className="brand-mark">✦</span>
          <span className="brand-name">Nightjar &amp; Co.</span>
        </Link>

        <nav className="nav-links">
          <NavLink to="/books" className={({ isActive }) => (isActive ? 'active' : '')}>
            Catalog
          </NavLink>
          <NavLink to="/add-book" className={({ isActive }) => (isActive ? 'active' : '')}>
            Add a Book
          </NavLink>
          {user ? (
            <button className="link-button" onClick={logout}>
              Sign out ({user.name.split(' ')[0]})
            </button>
          ) : (
            <NavLink to="/login" className={({ isActive }) => (isActive ? 'active' : '')}>
              Sign in
            </NavLink>
          )}
          <Link to="/cart" className="cart-link">
            Cart
            <span className="cart-badge">{totalItems}</span>
          </Link>
        </nav>
      </div>
    </header>
  );
}

export default Navbar;
