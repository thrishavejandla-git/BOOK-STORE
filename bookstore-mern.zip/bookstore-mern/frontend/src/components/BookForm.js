import React, { useState } from 'react';

const GENRES = [
  'Fiction',
  'Mystery',
  'Fantasy',
  'Science Fiction',
  'Drama',
  'Poetry',
  'Non-fiction',
  'General'
];

function BookForm({ onSubmit, submitting, error }) {
  const [form, setForm] = useState({
    title: '',
    author: '',
    genre: 'General',
    description: '',
    price: '',
    image: '',
    stock: 10
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({ ...form, price: Number(form.price), stock: Number(form.stock) });
  };

  return (
    <form className="book-form" onSubmit={handleSubmit}>
      {error && <p className="form-error">{error}</p>}

      <label>
        Title
        <input name="title" value={form.title} onChange={handleChange} required />
      </label>

      <label>
        Author
        <input name="author" value={form.author} onChange={handleChange} required />
      </label>

      <div className="form-row">
        <label>
          Genre
          <select name="genre" value={form.genre} onChange={handleChange}>
            {GENRES.map((g) => (
              <option key={g} value={g}>
                {g}
              </option>
            ))}
          </select>
        </label>

        <label>
          Price (₹)
          <input
            name="price"
            type="number"
            min="0"
            step="1"
            value={form.price}
            onChange={handleChange}
            required
          />
        </label>

        <label>
          Stock
          <input
            name="stock"
            type="number"
            min="0"
            step="1"
            value={form.stock}
            onChange={handleChange}
          />
        </label>
      </div>

      <label>
        Cover image URL
        <input
          name="image"
          value={form.image}
          onChange={handleChange}
          placeholder="https://…"
        />
      </label>

      <label>
        Description
        <textarea
          name="description"
          rows={4}
          value={form.description}
          onChange={handleChange}
        />
      </label>

      <button className="btn btn-primary" type="submit" disabled={submitting}>
        {submitting ? 'Saving…' : 'Add book to catalog'}
      </button>
    </form>
  );
}

export default BookForm;
