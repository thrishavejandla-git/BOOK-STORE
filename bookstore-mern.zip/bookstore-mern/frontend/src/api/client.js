const BASE_URL = process.env.REACT_APP_API_URL || '/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || 'Something went wrong');
  }
  return data;
}

export const api = {
  getBooks: (query = '') => request(`/books${query}`),
  getBook: (id) => request(`/books/${id}`),
  createBook: (book, token) => request('/books', { method: 'POST', body: book, token }),
  updateBook: (id, book, token) => request(`/books/${id}`, { method: 'PUT', body: book, token }),
  deleteBook: (id, token) => request(`/books/${id}`, { method: 'DELETE', token }),
  register: (payload) => request('/auth/register', { method: 'POST', body: payload }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload })
};
