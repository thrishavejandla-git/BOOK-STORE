import React, { useEffect, useState, useCallback } from 'react';
import { api } from '../api/client';
import BookCard from '../components/BookCard';
import Loader from '../components/Loader';

function BookListPage() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');

  const fetchBooks = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set('search', search);
    if (minPrice) params.set('minPrice', minPrice);
    if (maxPrice) params.set('maxPrice', maxPrice);
    const query = params.toString() ? `?${params.toString()}` : '';

    api
      .getBooks(query)
      .then(setBooks)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [search, minPrice, maxPrice]);

  useEffect(() => {
    fetchBooks();
  }, [fetchBooks]);

  const handleFilterSubmit = (e) => {
    e.preventDefault();
    fetchBooks();
  };

  return (
    <div className="section">
      <div className="section-heading">
        <h2>Catalog</h2>
      </div>

      <form className="filter-bar" onSubmit={handleFilterSubmit}>
        <input
          type="text"
          placeholder="Search by title…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <input
          type="number"
          placeholder="Min price"
          value={minPrice}
          onChange={(e) => setMinPrice(e.target.value)}
        />
        <input
          type="number"
          placeholder="Max price"
          value={maxPrice}
          onChange={(e) => setMaxPrice(e.target.value)}
        />
        <button className="btn btn-small" type="submit">
          Filter
        </button>
      </form>

      {loading ? (
        <Loader label="Scanning the shelves…" />
      ) : error ? (
        <p className="form-error">{error}</p>
      ) : books.length === 0 ? (
        <p className="empty-state">No books match those filters yet.</p>
      ) : (
        <div className="book-grid">
          {books.map((book) => (
            <BookCard key={book._id} book={book} />
          ))}
        </div>
      )}
    </div>
  );
}

export default BookListPage;
