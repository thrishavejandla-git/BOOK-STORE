import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { api } from '../api/client';
import BookForm from '../components/BookForm';
import { useAuth } from '../context/AuthContext';

function AddBookPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!user) {
    return (
      <div className="section">
        <h2>Add a book</h2>
        <p className="empty-state">
          You need to <Link to="/login">sign in</Link> before adding a book to the catalog.
        </p>
      </div>
    );
  }

  const handleSubmit = async (payload) => {
    setSubmitting(true);
    setError('');
    try {
      const book = await api.createBook(payload, user.token);
      navigate(`/books/${book._id}`);
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="section narrow">
      <h2>Add a book to the catalog</h2>
      <BookForm onSubmit={handleSubmit} submitting={submitting} error={error} />
    </div>
  );
}

export default AddBookPage;
