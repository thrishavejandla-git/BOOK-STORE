import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { api } from '../api/client';
import Loader from '../components/Loader';
import { useCart } from '../context/CartContext';

function BookDetailPage() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { addToCart } = useCart();

  useEffect(() => {
    setLoading(true);
    api
      .getBook(id)
      .then(setBook)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <Loader label="Fetching that title…" />;
  if (error) return <p className="form-error">{error}</p>;
  if (!book) return null;

  return (
    <div className="section detail-page">
      <Link to="/books" className="back-link">
        ← Back to catalog
      </Link>
      <div className="detail-grid">
        <div className="detail-cover">
          {book.image ? (
            <img src={book.image} alt={book.title} />
          ) : (
            <div className="book-card-cover placeholder large">{book.title.charAt(0)}</div>
          )}
        </div>
        <div className="detail-info">
          <p className="book-card-genre">{book.genre}</p>
          <h1>{book.title}</h1>
          <p className="detail-author">by {book.author}</p>
          <p className="detail-description">{book.description || 'No description yet.'}</p>
          <div className="detail-footer">
            <span className="detail-price">₹{book.price}</span>
            <span className="detail-stock">{book.stock} in stock</span>
          </div>
          <button className="btn btn-primary" onClick={() => addToCart(book)}>
            Add to cart
          </button>
        </div>
      </div>
    </div>
  );
}

export default BookDetailPage;
