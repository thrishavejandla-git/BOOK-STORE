import React from 'react';
import { Link } from 'react-router-dom';

function NotFoundPage() {
  return (
    <div className="section narrow" style={{ textAlign: 'center' }}>
      <h2>Page not found</h2>
      <p className="empty-state">
        That page slipped off the shelf. <Link to="/">Back to the front desk.</Link>
      </p>
    </div>
  );
}

export default NotFoundPage;
