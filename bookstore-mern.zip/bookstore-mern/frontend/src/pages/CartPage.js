import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

function CartPage() {
  const { items, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart();

  if (items.length === 0) {
    return (
      <div className="section">
        <h2>Your cart</h2>
        <p className="empty-state">
          Your cart is empty. <Link to="/books">Find something to read.</Link>
        </p>
      </div>
    );
  }

  return (
    <div className="section narrow">
      <h2>Your cart</h2>
      <ul className="cart-list">
        {items.map(({ book, quantity }) => (
          <li key={book._id} className="cart-row">
            <div>
              <p className="cart-row-title">{book.title}</p>
              <p className="cart-row-author">by {book.author}</p>
            </div>
            <div className="cart-row-controls">
              <input
                type="number"
                min="1"
                value={quantity}
                onChange={(e) => updateQuantity(book._id, Number(e.target.value))}
              />
              <span className="cart-row-price">₹{book.price * quantity}</span>
              <button className="link-button" onClick={() => removeFromCart(book._id)}>
                Remove
              </button>
            </div>
          </li>
        ))}
      </ul>
      <div className="cart-summary">
        <span>Total</span>
        <span className="cart-total">₹{totalPrice}</span>
      </div>
      <div className="cart-actions">
        <button className="btn btn-secondary" onClick={clearCart}>
          Clear cart
        </button>
        <button className="btn btn-primary" onClick={() => alert('Checkout is not wired up yet — this is a demo cart.')}>
          Checkout
        </button>
      </div>
    </div>
  );
}

export default CartPage;
