import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import BookCard from '../components/BookCard';
import Loader from '../components/Loader';

function HomePage() {
  const [featured, setFeatured] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .getBooks()
      .then((books) => setFeatured(books.slice(0, 3)))
      .catch(() => setFeatured([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <section className="hero">
        <div className="hero-copy">
          <p className="eyebrow">Open past midnight</p>
          <h1>
            A shelf for books that <em>find you</em>, not the other way around.
          </h1>
          <p className="hero-sub">
            Nightjar &amp; Co. is a small, odd, well-loved bookstore. Every title on the shelf
            was chosen, not stocked.
          </p>
          <Link to="/books" className="btn btn-primary">
            Browse the catalog
          </Link>
        </div>
        <div className="hero-shelf" aria-hidden="true">
          <div className="shelf-plank" />
          <div className="shelf-plank" />
          <div className="shelf-plank" />
        </div>
      </section>

      <section className="section">
        <div className="section-heading">
          <h2>Fresh on the shelf</h2>
          <Link to="/books">See the full catalog →</Link>
        </div>

        {loading ? (
          <Loader label="Pulling a few books off the shelf…" />
        ) : featured.length === 0 ? (
          <p className="empty-state">
            No books yet. Run the seed script, or{' '}
            <Link to="/add-book">add the first one</Link>.
          </p>
        ) : (
          <div className="book-grid">
            {featured.map((book) => (
              <BookCard key={book._id} book={book} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

export default HomePage;
