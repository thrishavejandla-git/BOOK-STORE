# Nightjar & Co. — BookStore (MERN Stack)

A full-stack bookstore application built with MongoDB, Express, React, and Node.js (MERN).
Browse a catalog, view book details, add books (once signed in), and manage a shopping cart.

```
client (React)  →  server (Express/Node)  →  database (MongoDB)
```

## Project structure

```
bookstore-mern/
├── backend/
│   ├── config/db.js            MongoDB connection
│   ├── models/                 Book.js, User.js (Mongoose schemas)
│   ├── controllers/            bookController.js, authController.js
│   ├── routes/                 bookRoutes.js, authRoutes.js
│   ├── middleware/authMiddleware.js
│   ├── server.js                Express app entry point
│   ├── seed.js                  Sample data loader
│   ├── .env.example
│   └── package.json
└── frontend/
    ├── public/index.html
    ├── src/
    │   ├── api/client.js         fetch wrapper for the REST API
    │   ├── context/              CartContext.js, AuthContext.js
    │   ├── components/           Navbar, Footer, BookCard, BookForm, Loader
    │   ├── pages/                Home, BookList, BookDetail, AddBook, Cart, Login, Register, NotFound
    │   ├── styles/index.css       theme
    │   ├── App.js
    │   └── index.js
    ├── .env.example
    └── package.json
```

## Prerequisites

- Node.js 18+ and npm
- A MongoDB database — either a local install (`mongodb://127.0.0.1:27017`) or a free
  [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env and set MONGODB_URI (and JWT_SECRET) as needed
npm run seed     # optional: loads 6 sample books
npm run dev      # starts on http://localhost:5000 (uses nodemon)
# or: npm start
```

Verify it's running:

```bash
curl http://localhost:5000/api/health
curl http://localhost:5000/api/books
```

## 2. Frontend setup

Open a second terminal:

```bash
cd frontend
npm install
npm start        # starts on http://localhost:3000
```

The dev server proxies API calls to `http://localhost:5000` (see the `proxy` field in
`frontend/package.json`), so no CORS configuration is needed in development.

## API reference

| Method | Route              | Auth required | Description              |
|--------|--------------------|:--------------:|--------------------------|
| GET    | /api/books         | No             | List books (supports `?search=`, `?genre=`, `?minPrice=`, `?maxPrice=`) |
| GET    | /api/books/:id     | No             | Get a single book |
| POST   | /api/books         | Yes            | Create a book |
| PUT    | /api/books/:id     | Yes            | Update a book |
| DELETE | /api/books/:id     | Yes            | Delete a book |
| POST   | /api/auth/register | No             | Create an account, returns a JWT |
| POST   | /api/auth/login    | No             | Log in, returns a JWT |
| GET    | /api/health        | No             | Health check |

Authenticated requests send `Authorization: Bearer <token>`; the React app stores this
token in memory/session after login and attaches it automatically when adding books.

## Features implemented

- MVC-structured Express backend (models / controllers / routes)
- Mongoose schemas for `Book` and `User`, with password hashing (bcrypt)
- JWT-based authentication protecting write routes
- React Router v6 multi-page frontend (Home, Catalog, Detail, Add Book, Cart, Login, Register)
- Search and price-range filtering on the catalog page
- In-memory shopping cart (add/remove/update quantity, running total)
- Seed script with sample book data
- Responsive, custom-themed UI (no default UI kit)

## Suggested next steps

- Persist the cart and checkout flow to an `Order` model
- Add pagination to `GET /api/books`
- Add image upload instead of URL-only cover images
- Deploy backend (e.g. Render/Railway) and frontend (e.g. Vercel/Netlify), and point
  `REACT_APP_API_URL` at the deployed backend URL
