// Run with: npm run seed
// Populates the database with sample books for local development/demo purposes.
require('dotenv').config();
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const Book = require('./models/Book');

const sampleBooks = [
  {
    title: 'The Silent Cartographer',
    author: 'Maren Aldric',
    genre: 'Mystery',
    description: 'A cartographer discovers a map that redraws itself overnight.',
    price: 449,
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400',
    stock: 12
  },
  {
    title: 'Ledger of Small Gods',
    author: 'Priya Nandakumar',
    genre: 'Fantasy',
    description: 'An accountant is hired to balance the books of forgotten deities.',
    price: 599,
    image: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?w=400',
    stock: 8
  },
  {
    title: 'Static and Salt',
    author: 'Jonas Webb',
    genre: 'Science Fiction',
    description: 'A radio operator on a dying colony ship picks up a signal from home.',
    price: 379,
    image: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=400',
    stock: 15
  },
  {
    title: 'The Quiet Ledger',
    author: 'Elin Fossum',
    genre: 'Drama',
    description: 'Three siblings inherit their grandmother\u2019s bookshop and its debts.',
    price: 329,
    image: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?w=400',
    stock: 20
  },
  {
    title: 'Copper Wire Sonnets',
    author: 'Desmond Iyer',
    genre: 'Poetry',
    description: 'A collection exploring industrial landscapes through classical verse forms.',
    price: 259,
    image: 'https://images.unsplash.com/photo-1476275466078-4007374efbbe?w=400',
    stock: 10
  },
  {
    title: 'The Archivist\u2019s Debt',
    author: 'Naomi Castellan',
    genre: 'Mystery',
    description: 'A librarian uncovers a decades-old theft hidden inside the card catalog.',
    price: 419,
    image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=400',
    stock: 6
  }
];

(async () => {
  await connectDB();
  try {
    await Book.deleteMany({});
    await Book.insertMany(sampleBooks);
    console.log(`Seeded ${sampleBooks.length} books successfully.`);
  } catch (err) {
    console.error('Seeding failed:', err.message);
  } finally {
    mongoose.connection.close();
  }
})();
