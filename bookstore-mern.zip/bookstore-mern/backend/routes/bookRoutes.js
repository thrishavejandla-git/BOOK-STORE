const express = require('express');
const {
  getAllBooks,
  getBookById,
  createBook,
  updateBook,
  deleteBook
} = require('../controllers/bookController');
const protect = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', getAllBooks);
router.get('/:id', getBookById);

// Writes require a logged-in user
router.post('/', protect, createBook);
router.put('/:id', protect, updateBook);
router.delete('/:id', protect, deleteBook);

module.exports = router;
